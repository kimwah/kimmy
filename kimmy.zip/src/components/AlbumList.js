import React, { Component } from 'react';
import { View, Text } from 'react-native';
//import axios from 'axios';

class AlbumList extends Component {
    //state = { albums: [] };
    // getInitialState(){
    //     return {
    //         albums:[];
    //     };
    // }
    constructor(props) {
        super(props);
        this.state = {
            albums: [],
        };
    }    
    componentWillMount() {
        //console.log('componentWillMount in AlbumList');
        fetch('https://rallycoding.herokuapp.com/api/music_albums')
            //.then(response => console.log(response));
            .then(response => response.json())
            .then(data => {
                 //console.log(data);
                 this.setState({ albums: data });
             });   
        // axios.get('https://rallycoding.herokuapp.com/api/music_albums')
        //     .then(response => console.log(response));    


    }

    render() {
        var populateAlbum = ()=>{
            return this.state.albums.map((album) => {
                return (<Text>{album.title}</Text> );  
            });
        }        
        console.log(this.state);
        return (
            <View>
                {populateAlbum()}
            </View>
        );
    }
}
export default AlbumList;